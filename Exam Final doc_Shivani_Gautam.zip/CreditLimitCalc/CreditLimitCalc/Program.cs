﻿using System;

namespace CreditLimitCalc
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to our Department Store!");

            int accountNumber;
            float beginningBalance, totalCharges, totalCredits, creditLimit, accountBalance;

            Console.WriteLine("Enter account number (or -1 to end ): ");

            accountNumber = Convert.ToInt32(Console.ReadLine());

            while (accountNumber != -1)
            {
                Console.WriteLine("Enter Balance: ");
                beginningBalance = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter Charges: ");
                totalCharges = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Credits: ");
                totalCredits = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter Credit Limit: ");
                creditLimit = Convert.ToInt32(Console.ReadLine());

                accountBalance = beginningBalance + totalCharges - totalCredits;
                Console.WriteLine("New Balance is {0}", accountBalance);

                if (accountBalance > totalCredits)
                    Console.WriteLine("Credit Limit Exceeded");

                Console.Write("\nEnter Account Number (or -1 to quit): ");
                accountNumber = Convert.ToInt32(Console.ReadLine());
            }
        }
    }
}
    
