﻿using System;

namespace swap
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            string a = "dog", b = "cat";
            Console.WriteLine("Before Swapping: {0} {1}", a, b);

            Swap(ref a, ref b);
            Console.WriteLine("After Swapping: {0} {1}", a, b);


        }

        static void Swap(ref string a, ref string b)
        {
            string temp = a;
            a = b;
            b = temp;
            //Console.WriteLine("Inside the method: {0} {1}", a, b);
        }
    }
}
