﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace lab02
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Eye Glass Store");


            var Glasses_prices = new Dictionary<int, decimal>();
            Glasses_prices.Add(1, 40);
            Glasses_prices.Add(2, 25);

            var Coating_prices = new Dictionary<int, decimal>();
            Coating_prices.Add(1, 12.5M);
            Coating_prices.Add(2, 9.99M);

            int Glasses;
            int Coating;

            Console.WriteLine("*** MENU ***");

            Console.WriteLine("****Select options by typing the number for following 2 questions -->****");

            Console.WriteLine("What kind of glasses would you like:");
            do
            {
                Console.Write("1 -> prescription, 2 -> non-prescription : ");
            }
            while (!Int32.TryParse(Console.ReadLine(), out Glasses) || !Glasses_prices.ContainsKey(Glasses));

            Console.WriteLine("What kind of coating would you like:");
            do
            {
                string Message = "";

                if (!GlassesRequireCoating(Glasses))
                {
                    Message += "0 -> No coating, ";
                }

                Console.Write(Message + "1 -> anti-glare, 2 -> brown tint : ");
            }
            while (!Int32.TryParse(Console.ReadLine(), out Coating) || !CoatingSelectionIsValid(Coating, Glasses, Coating_prices));

            Console.WriteLine($"****Your total cost is ${Glasses_prices[Glasses] + (Coating_prices.ContainsKey(Coating) ? Coating_prices[Coating] : 0)}****");

            Console.Read();
        }

        public static bool GlassesRequireCoating(int glasses)
        {
            int[] GlassesRequiringCoating = { 1 };

            return GlassesRequiringCoating.Contains(glasses);
        }

        public static bool CoatingSelectionIsValid(int coatingSelection, int glassesSelection, IDictionary<int, decimal> coatingPrices)
        {
            return GlassesRequireCoating(glassesSelection) ? coatingPrices.ContainsKey(coatingSelection) : true;
        }
    }
    }
