$(document).ready(function() {
	var emailPattern = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}\b/;
    $("#arrival_date").focus();
    $("#reservation_form").submit(
        function(event)
    {
        var isValid = true;
        var arrivalDate = $("#arrival_date").val().trim();
        if(arrivalDate == "")
            {
                $("#arrival_date").next().text("Field is required!");
                isValid = false;
            }
        else{
            $("#arrival_date").next().text("");
        }
        $("#arrival_date").val(arrivalDate);
        
         var nights = $("#nights").val().trim();
        if(nights == "")
            {
                $("#nights").next().text("Field is required!");
                isValid = false;
            }
        else if(isNan($("#nights").val()))
        {
            $("#nights").next().text("Numeric field should be entered.");
            isValid = false;
        }
        else{
            $("#nights").next().text("");
        }
        $("#nights").val(nights);
        
         var name = $("name").val().trim();
        if(name == "")
            {
                $("#name").next().text("Field is required!");
                isValid = false;
            }
        else{
            $("#name").val(name);
            $("#name").next().text("");
        }
        $("#name").val(name);
        
         var email_add = $("email_add").val();
        if(email_add == "")
            {
                $("#email_add").next().text("Field is required!");
                isValid = false;
            }
        else if(!emailPattern.test(email)){
            $("#email").next().text("Valid Email Address should be entered.");
            isValid = false;
        }
        else{
            $("#email_add").next().text("");
        }
        $("#email_add").val(email_add);
        
         var phone = $("phone").val().trim();
        if(phone == "")
            {
                $("#phone").next().text("Field is required!");
                isValid = false;
            }
        else{
            $("#phone").next().text("");
        }
        $("#phone").val(phone);
        if(isValid == false)
            {
                event.preventDefault();
            }
        
    });
}); // end ready
