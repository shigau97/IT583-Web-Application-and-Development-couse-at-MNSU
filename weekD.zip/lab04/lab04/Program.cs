﻿using System;

namespace lab04
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            int a = 1, b = 2, c = 5;
            double x = 2.2, y = 4.4, z = 6.6, ans;

            ans = average(a, b);
            Console.WriteLine("average(a,b) = " + ans);
            ans = average(a, b, c);
            Console.WriteLine("average(a,b,c) = " + ans);
            ans = average(x, y);
            Console.WriteLine("average(x,y) = " + ans);
            ans = average(x, y, z);
            Console.WriteLine("average(x,y,z) = " + ans);
            Console.ReadLine();
        }
        public static double average(double n1, double n2)
        {
            return (n1 + n2) / 2.0;

        }
        public static double average(double n1, double n2, double n3)
        {
            return (n1 + n2 + n3) / 3.0;

        }
    }
}

 
        // 1) No, we dont require a parameter because double it added their which itself is fine for both integer and double. 

        // 2) Well no because it would be easier as it is broken down.
        
        // 3) Yes, it is legal as the function is in double it will convert into double.
